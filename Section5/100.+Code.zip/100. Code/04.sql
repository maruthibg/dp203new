
-- Lab - Metadata activity

CREATE TABLE [dbo].[Customer]
(
  [customerid] int,
  [customername] varchar(20),  
  [registered] bit,
  [FileDate] datetime,
  [FileName] varchar(200)
)