-- Lab - Processing JSON Arrays

CREATE TABLE [customercourse]
(
[customerid] int,
[customername] varchar(200),
[registered] BIT,
[courses] varchar(200)
)