-- Lab - Processing JSON Objects

drop table customercourse

CREATE TABLE [customercourse]
(
[customerid] int,
[customername] varchar(200),
[registered] BIT,
[courses] varchar(200),
[mobile] varchar(200),
[city] varchar(200)
)